import torch.nn as nn
import torch
import torch.nn.functional as F
import numpy as np
from torch.nn.functional import normalize

class Encoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            nn.Linear(2000, feature_dim),
        )

    def forward(self, x):
        return self.encoder(x)

# Decoder
class Decoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, input_dim)
        )

    def forward(self, x):
        return self.decoder(x)

class MembershipCollector(nn.Module):
    def __init__(self, input_dim, num_clusters):
        super(MembershipCollector, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(64, num_clusters)
        )

    def forward(self, x):
        h = self.net(x)
        return self.get_norm_outputs(h)
    
    def get_norm_outputs(self, inputs):
        norm = torch.norm(inputs, p=2, dim=1, keepdim=True)
        norm = torch.clamp(norm, min=1e-10)  
        outputs = inputs / norm
        outputs = torch.relu(outputs)
        outputs = outputs + 1e-10
        outputs = outputs / outputs.sum(dim=1, keepdim=True)
        return outputs

class Network(nn.Module):
    def __init__(self, view, input_size, feature_dim, high_feature_dim, class_num, device):
        super(Network, self).__init__()
        self.view = view  
        self.epsilon = 1e-10  
        self.num_clusters = class_num
        
        self.encoders = nn.ModuleList([Encoder(input_size[v], feature_dim).to(device) for v in range(view)])
        self.decoders = nn.ModuleList([Decoder(input_size[v], feature_dim).to(device) for v in range(view)])
        
        self.MembershipCollectors = nn.ModuleList([MembershipCollector(feature_dim, class_num).to(device) for v in range(view)])
        self.feature_fusion_module = nn.Sequential(
            nn.Linear(self.view * feature_dim, 256),
            nn.ReLU(),
            nn.Linear(256, high_feature_dim)
        )
        self.common_information_module = nn.Sequential(
            nn.Linear(feature_dim, high_feature_dim)
        )
        self.label_contrastive_module = nn.Sequential(nn.Linear(feature_dim, class_num), nn.Softmax(dim=1))
    
    def Fusion(self, zs, zs_gradient):
        input = torch.cat(zs, dim=1) if zs_gradient else torch.cat(zs, dim=1).detach()
        return normalize(self.feature_fusion_module(input),dim=1)
    
    def forward(self, xs):
        xrs = [] 
        zs = []    
        rs = []
        Memberships = []  
        Credibilitys = []  
        Uncertaintys = []  
        
        for v in range(self.view):
            x = xs[v]
            z = self.encoders[v](x)
            xr = self.decoders[v](z)
            r = normalize(self.common_information_module(z),dim=1)
            membership = self.MembershipCollectors[v](z)
            credibility = self.get_cluster_credibility(membership)
            uncertainty = self.get_Uncertainty(credibility)
            
            zs.append(z)
            xrs.append(xr)
            rs.append(r)
            Memberships.append(membership)
            Credibilitys.append(credibility)
            Uncertaintys.append(uncertainty)
        
        weights = []
        for view in range(self.view):
            conflict_degree = 0.0
            for v in range(self.view):
                if v != view:
                    conflict_degree += self.get_ConflictDegree(Memberships[view], Memberships[v]) * (1 / (self.view - 1))
            weight = (1 - Uncertaintys[view]) * (1 - conflict_degree) + self.epsilon
            weights.append(weight)
    
        Weights = torch.stack(weights)
        Weights = torch.softmax(Weights, dim=0)
        H = self.Fusion(zs, True)    
        return xrs, zs, rs, H ,Credibilitys, Memberships, Weights
    
    def get_cluster_credibility(self, membershipDegree): 
        if membershipDegree.shape[1] > 1:
            top2 = torch.topk(membershipDegree, k=2, dim=1)[0]
            sec_max = torch.where(
                membershipDegree == top2[:,0].unsqueeze(1), 
                top2[:,1].unsqueeze(1), 
                top2[:,0].unsqueeze(1)
            )
            return (membershipDegree + 1 - sec_max) / 2
        else:
            return membershipDegree
    
    def get_Uncertainty(self, credibility):
        nonzero_indices = torch.nonzero(credibility)
        cluster_num = credibility.shape[1] 
        if len(nonzero_indices) > 1 and cluster_num > 1:
            H = torch.sum(
                (-credibility * torch.log(credibility + self.epsilon) - 
                 (1 - credibility) * torch.log(1 - credibility + self.epsilon)), 
                dim=1, 
                keepdim=True
            )
            H = H / (cluster_num * torch.log(torch.tensor(2.0)))
        else:
            H = torch.zeros_like(credibility[:, :1])
    
        return H
    
    def get_ConflictDegree(self, vector1, vector2):
        return (1 - F.cosine_similarity(vector1, vector2, dim=1, eps=1e-8)).view(-1, 1)