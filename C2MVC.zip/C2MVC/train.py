import os
import torch
from network import Network
from torch.nn import functional as F
from metric import valid
from torch.utils.data import Dataset
import numpy as np
import argparse
import random
from loss import Loss
from dataloader import load_data
import math
from sklearn.metrics import v_measure_score

# 数据集名称列表
Dataname = 'Caltech-3V'

# 命令行参数解析
parser = argparse.ArgumentParser(description='train')
parser.add_argument('--dataset', default=Dataname)
parser.add_argument('--batch_size', default=256, type=int)
parser.add_argument("--feature_dim", default=512)
parser.add_argument("--high_feature_dim", default=128)
parser.add_argument("--learning_rate", default=0.0003)
parser.add_argument("--weight_decay", default=0.)

parser.add_argument("--pre_epochs", default=200)
parser.add_argument("--con_epochs", default=200)
parser.add_argument("--temperature_f", default=0.5)
parser.add_argument('--device', type=str, default='cuda:0', metavar='N',help='gpu or cpu (default: cuda:0)')
args = parser.parse_args()

device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
os.environ["CUDA_VISIBLE_DEVICES"] = args.device.split(':')[-1] if 'cuda' in args.device else ''
os.environ["OMP_NUM_THREADS"] = '3'


if args.dataset == "handwritten":
    args.con_epochs = 15
    seed = 10
if args.dataset == "Cifar10":
    args.con_epochs = 10
    seed = 10
if args.dataset == "Synthetic3d":
    args.con_epochs = 100
    seed = 100
if args.dataset == "Caltech-3V":
    args.con_epochs = 100
    seed = 30
if args.dataset == "Caltech-4V":
    args.con_epochs = 100
    seed = 100
if args.dataset == "Caltech-5V":
    args.con_epochs = 100
    seed = 1000000

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

setup_seed(seed)

dataset, dims, view, data_size, class_num = load_data(args.dataset)
data_loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size,        
        shuffle=True,
        drop_last=True,
        generator=torch.Generator().manual_seed(seed)
    )

def pretrain(epoch):
    tot_loss = 0.
    for batch_idx, (xs, _, _) in enumerate(data_loader):
        for v in range(view):
            xs[v] = xs[v].to(device)
        optimizer.zero_grad()
        xrs, _, _, _ ,_, _, _ = model(xs)
        loss_list = []
        for v in range(view):
            loss_list.append(F.mse_loss(xrs[v], xs[v]))
        loss = sum(loss_list)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        tot_loss += loss.item()
    print('Epoch {}'.format(epoch), 'Loss:{:.6f}'.format(tot_loss/len(data_loader)))

def contrastive_train(epoch):
    tot_loss = 0.
    for batch_idx, (xs, _, _) in enumerate(data_loader):
        for v in range(view):
            xs[v] = xs[v].to(device)
        optimizer.zero_grad()
        xrs, zs, rs, H ,Credibilitys, Memberships, Weights = model(xs)
        low_feature = torch.cat(zs, dim=1)
        loss_list = []

        for v in range(view):
            loss_list.append(criterion.forward_feature(rs[v], H, Weights[v]))
            loss_list.append(F.mse_loss(xs[v], xrs[v]))

        loss = sum(loss_list)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        tot_loss += loss.item()
    print('Epoch {}'.format(epoch), 'Loss:{:.6f}'.format(tot_loss/len(data_loader)))

accs = []
nmis = []
purs = []

if not os.path.exists('./models'):
    os.makedirs('./models')

accs = []
nmis = []
purs = []
if not os.path.exists('./models'):
    os.makedirs('./models')
T = 1
for i in range(T):
    print("ROUND:{}".format(i+1))
    setup_seed(seed)

    model = Network(view, dims, args.feature_dim, args.high_feature_dim, class_num,device)

    print(model)
    model = model.to(device)
    state = model.state_dict()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    criterion = Loss(args.batch_size, class_num, args.temperature_f, device).to(device)
    best_acc, best_nmi, best_pur = 0, 0, 0

    epoch = 1
    while epoch <= args.pre_epochs:
        pretrain(epoch)
        epoch += 1

    while epoch <= args.pre_epochs + args.con_epochs:
        contrastive_train(epoch)
        acc, nmi, pur = valid(model, device, dataset, view, data_size, class_num, eval_h=False, epoch=epoch)

        if acc > best_acc:
            best_acc, best_nmi, best_pur = acc, nmi, pur
            state = model.state_dict()
            torch.save(state, './models/' + args.dataset + '.pth')
        epoch += 1

    accs.append(best_acc)
    nmis.append(best_nmi)
    purs.append(best_pur)
    print('The best clustering performace: ACC = {:.4f} NMI = {:.4f} PUR={:.4f}'.format(best_acc, best_nmi, best_pur))